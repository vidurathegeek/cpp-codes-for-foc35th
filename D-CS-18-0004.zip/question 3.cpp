#include <iostream>

using namespace std;

//variable declaration
int choice;
float h,b,r;
long double aot,aoc,aos,aor;

//function declaration
float tranarea(float h, float b);
float trancircle(float r);
float transq(float h);
float tranrec(float h, float b);

int main(){
	cout << " Enter your choice to find the area \n 1).Triangle \n 2).Circle \n 3).Square \n 4).Rectangle \n 5).Exit" << endl;
	cin >> choice;
	do{
		switch(choice){
			case 1: cout << "Enter Height " << endl;
					cin >> h;
					cout << "Enter Base " << endl;
					cin >> b;
					tranarea(h,b);
					break;
			case 2: cout << "Enter radius " << endl;
					cin >> r;
					trancircle(r);
					break;
			case 3: cout << "Enter Height " << endl;
					cin >> h;
					transq(h);
					break;
			case 4: cout << "Enter Height " << endl;
					cin >> h;
					cout << "Enter Width " << endl;
					cin >> b;
					tranrec(h,b);
					break;
		}
	cout << "Enter a choice" << endl;
	cin >> choice;

	} while(choice != 5);
	cout << "Goodbye" << endl;
}

float tranarea(float h, float b){
	aot = (h * b) * 0.5;
	cout <<"Area of the Triangle " << aot << endl;
	cout << endl; 
}

float trancircle(float r){
	aoc = 3.14159 * (r*r) ;
	cout << "Area of the Circle " << aoc << endl;
	cout << endl;
}

float transq(float h){
	aos = h * h;
	cout << "Area of the Square " << aos <<endl;
	cout << endl;
}

float tranrec(float h, float b){
	aor = h * b;
	cout << "Area of the Rectangle " << aor << endl;
	cout << endl;
}

//FOC 35th vidurathegeek
