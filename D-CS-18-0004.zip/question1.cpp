#include <iostream>

using namespace std;

//variable decleration and initialization
int choice, num1;
int count = 0;


//function blueprint
float facto(int num1);
int primeornot(int num1);
int oddoreven(int num1);	

//main function
int main(){
	cout << "Hi Welcome to Assignment Enter your preference to proceed" << endl;
	cout << "Enter 1 to get Factorial" << endl;
	cout << "Enter 2 to get Check wether it's a prime number or not" << endl;
	cout << "Enter 3 to check wether it's odd or even" << endl;
	cout << "Enter 4 to Exit \n " << endl;

	cout << "Enter a Choice" << endl;
	cin >> choice;

	while(choice != 4){
		//switch case starts
		switch(choice){
			case 1 :
				cout << "Enter your number" << endl;
				cin >> num1;
				facto(num1);  //Calling facto function
				break;

			case 2 :
				cout << "Enter your number" << endl;
				cin >> num1;
				primeornot(num1); // Calling primeornot function
				break;

			case 3:
				cout << "Enter your number" << endl;
				cin >> num1;
				oddoreven(num1); // Calling oddoreven function 
				break;
		}
	cout << "Enter a Choice" << endl;
	cin >> choice;
	}
	cout << "Goodbye" << endl;
}

float facto(int num1){
	unsigned long long fact = 1;
	for(int i=1; i<=num1; i++){
		fact = fact * i;
	}
	cout << fact << "\n" << endl;
	return fact;
}

int primeornot(int num1){
	for(int t=1; t<=num1; t++){
		if(num1%t == 0){
			count +=1;
		} 
	}
	if(count > 2){
		cout << "Not Prime" << "\n" <<endl;
	}
	else{
		cout << "Prime" << "\n" << endl;
	}
}

int oddoreven(int num1){
	if(num1%2 == 0){
		cout << "Even" << "\n" << endl;
	}
	else {
		cout << "Odd" << "\n" << endl;
	}
}

//FOC 35th vidurathegeek


