#include <iostream>
#include <stdlib.h>


const float applePrice = 20;
const float breadPrice = 60;
const float cheesePrice = 250;

int choice;
float bud,change,aNo,bNo,cNo,amountApple,amountBread,amountCheese;

float appleCount(float aNo);
float breadCount(float bNo);
float cheeseCount(float cNo);

using namespace std;

int main(){
	cout << "-----------------------------" << endl;
	cout << "\t Item \t Price \n ----------------------------- \n" << endl;
	cout << "\t Apples \t 20 \n \t Bread \t \t 60 \n \t Cheese \t 250 \n -----------------------------" << endl;
	
	cout << "Enter your budget" << endl;
	cin >> bud;
	cout << "Enter your choice \n 1).Apples \n 2).Bread \n 3).Cheese \n 3).Exit \n GO WITH RESPECTIVE ORDER. DON'T JUMP IN OR OUT" << endl;
	cin >> choice;


	while(choice != 4){
		switch(choice){
			case 1: cout << "How much you need" << endl;
					cin >> aNo;
					appleCount(aNo);
					break;
			case 2: cout << "How much you need" << endl;
					cin >> bNo;
					breadCount(bNo);
					break;
			case 3: cout << "How much you need" << endl;
					cin >> cNo;
					cheeseCount(cNo);
					break;
		}
		cout << "Enter your choice \n 1).Apples \n 2).Bread \n 3).Cheese \n 4).Exit \n GO WITH RESPECTIVE ORDER. DON'T JUMP IN OR OUT" << endl;
		cin >> choice;
	} 
}

float appleCount(float aNo){
	amountApple = aNo * applePrice;
	if(amountApple <= bud){
		change = bud - amountApple;
		cout << "Here your change :" << change << endl;;
	}
	else {
		cout << "You have no enough Money" << endl;
		exit (EXIT_FAILURE);
	}
}

float breadCount(float bNo){
	amountBread = bNo * breadPrice;
	if(amountBread <=  change){
		change -= amountBread;
		cout << "Here your change :" << change << endl;;
	}
	else {
		cout << "You have no enough Money" << endl;
		exit (EXIT_FAILURE);
	}
}

float cheeseCount(float cNo){
	amountCheese = cNo * cheesePrice;
	if(amountCheese <= change){
		change -= amountCheese;
		cout << "Here your change :" << change << endl;;
	}
	else {
		cout << "You have no enough Money" << endl;
		exit (EXIT_FAILURE);
	}
}

//FOC 35th vidurathegeek