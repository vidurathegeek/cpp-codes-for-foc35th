#include <iostream>

using namespace std;

int choice;
float num1,num2,tot,sub;
float multi = 1;
float diva;

void showChoice();
int sum(int num1, int num2);
int subs(int num1, int num2);
int mul(int num1, int num2);
int div(int num1, int num2);

int main(){
	showChoice();
	cout << "Enter the respective number to perform your calculation \n 1: Add \n 2: Subtract \n 3: Multiply \n 4: Divide \n 5: Exit" << endl;
	cin >> choice;
	while ( choice != 5){
		switch(choice){
			case 1:
				cout << "Enter number 1 \n" << endl;
				cin >> num1 ;
				cout << "Enter number 2 \n" << endl;
				cin >> num2 ;
				sum(num1,num2);
				break;
			case 2:
				cout << "Enter number 1 \n" << endl;
				cin >> num1;
				cout << "Enter number 2 \n" << endl;
				cin >> num2;
				subs(num1,num2);
				break;
			case 3:
				cout << "Enter number 1 \n" << endl;
				cin >> num1;
				cout << "Enter number 2 \n" << endl;
				cin >> num2;
				mul(num1,num2);
				break;
			case 4:
				cout << "Enter number 1 \n" << endl;
				cin >> num1;
				cout << "Enter number 2 \n" << endl;
				cin >> num2;
				div(num1,num2);
				break;
	}
	cout << "Enter the respective number to perform your calculation \n 1: Add \n 2: Subtract \n 3: Multiply \n 4: Divide \n 5: Exit" << endl;
	cin >> choice;
	}
	cout << "Goodbye" << endl;
}

void showChoice(){
	cout << "Enter 1st Number that you want to perform the calculation \n Then enter 2nd number that you want to perform the calculation" << endl;
}

int sum(int num1, int num2){
	tot = num1 + num2;
	cout << "Sum of 2 Entered numbers : " << tot << "\n" <<endl;
}

int subs(int num1, int num2){
	sub = num1 - num2;
	cout << "Result of number1 - number2 : " << sub << "\n" <<endl;
}

int div(int num1, int num2){
	diva = num1 / num2 ;
	cout << "Division result of number 1 / number 2 : " << diva << "\n" <<endl;
}

int mul(int num1, int num2){
	multi = num1 * num2;
	cout <<"Multiplication of enter numbers : " <<  multi << "\n" <<endl;
}

//FOC 35th vidurathegeek
